/*********************************************************************************
*  WEB700 – Assignment 2
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: Nirajbhai Limbasiya Student ID: 146215231 Date: 14/06/2024
*
********************************************************************************/ 

const fs = require('fs');

class Data {
    constructor(students, courses) {
        this.students = students;
        this.courses = courses;
    }

    static initialize() {
        return new Promise((resolve, reject) => {
            let studentDataFromFile, courseDataFromFile;

            // Read students.json
            fs.readFile('./data/students.json', 'utf8', (err, dataFromStudentsFile) => {
                if (err) {
                    reject("Unable to read students.json");
                    return;
                }

                // student data
                try {
                    studentDataFromFile = JSON.parse(dataFromStudentsFile);
                } catch (error) {
                    reject("Error parsing students.json");
                    return;
                }

                // Read courses.json
                fs.readFile('./data/courses.json', 'utf8', (err, dataFromCoursesFile) => {
                    if (err) {
                        reject("Unable to read courses.json");
                        return;
                    }

                    // course data
                    try {
                        courseDataFromFile = JSON.parse(dataFromCoursesFile);
                    } catch (error) {
                        reject("Error parsing courses.json");
                        return;
                    }

                    // Create Data instance
                    const dataCollection = new Data(studentDataFromFile, courseDataFromFile);
                    resolve(dataCollection);
                });
            });
        });
    }

    getAllStudents() {
        return new Promise((resolve, reject) => {
            if (this.students.length === 0) {
                reject("No students found");
                return;
            }
            resolve(this.students);
        });
    }

    getTAs() {
        return new Promise((resolve, reject) => {
            const TAs = this.students.filter(student => student.TA);
            if (TAs.length === 0) {
                reject("No TAs found");
                return;
            }
            resolve(TAs);
        });
    }

    getCourses() {
        return new Promise((resolve, reject) => {
            if (this.courses.length === 0) {
                reject("No courses found");
                return;
            }
            resolve(this.courses);
        });
    }

    getStudentsByCourse(course) {
        return new Promise((resolve, reject) => {
            const filteredStudents = this.students.filter(student => student.course === parseInt(course));
            if (filteredStudents.length > 0) {
                resolve(filteredStudents);
            } else {
                reject("no results returned");
            }
        });
    }

    getStudentByNum(num) {
        return new Promise((resolve, reject) => {
            const student = this.students.find(student => student.studentNum === parseInt(num));
            if (student) {
                resolve(student);
            } else {
                reject("no results returned");
            }
        });
    }
}

module.exports = Data;
