/*********************************************************************************
*  WEB700 – Assignment 03
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part 
*  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: nirajbhai limbasiya Student ID: 146215231  Date: 14/06/2024
*
********************************************************************************/ 

var HTTP_PORT = process.env.PORT || 8080;
var express = require("express");
var app = express();
const port = 8080;
// setup a 'route' to listen on the default url path
app.get("/", (req, res) => {
    res.send("Hello World!");
});

app.get('/about', (req, res) => {
    res.send('Welcome to the About Page');
});

app.get('/htmlDemo', (req, res) => {
    res.send('Welcome to the HTML Demo Page');
});

app.get('/students', async (req, res) => {
    try {
        const students = await collegeData.getAllStudents();
        res.json(students);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.get('/students/:studentNum', async (req, res) => {
    try {
        const student = await collegeData.getStudentByNum(req.params.studentNum);
        res.json(student);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.get('/studentsByCourse/:course', async (req, res) => {
    try {
        const students = await collegeData.getStudentsByCourse(req.params.course);
        res.json(students);
    } catch (error) {
        res.status(500).send(error.message);
    }
});
// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT, () => {
    console.log("Server listening on port: " + HTTP_PORT);
});
